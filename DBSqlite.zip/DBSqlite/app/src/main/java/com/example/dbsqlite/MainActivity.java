package com.example.dbsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //ALERT
    //Get Concern about customer ID it will create Error
    //if Id is previously get Assigned to another Customer

    EditText eID,eNM,eAD,ePhNo;
    TextView res;
    Button b1,b2;
    DBConn mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eID = findViewById(R.id.editTextTextPersonName);
        eNM = findViewById(R.id.editTextTextPersonName2);
        eAD = findViewById(R.id.editTextTextPersonName3);
        ePhNo = findViewById(R.id.editTextTextPersonName4);
        res = findViewById(R.id.t2);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);

        mydb = new DBConn(this,"cust",null,1);

    }

    public void saveData(View view) {
        mydb.insertData(Integer.parseInt(eID.getText().toString()), eNM.getText().toString(), eAD.getText().toString(),
                (int) Long.parseLong(ePhNo.getText().toString()));
    }

    public void loadData(View view) {
        String r = mydb.getData();
        res.setText(r);
    }

    public void clearData(View view) {
        eID.setText("");
        eNM.setText("");
        eAD.setText("");
        ePhNo.setText("");

        // Delete the data from the database
        mydb.deleteAllData();
    }
}