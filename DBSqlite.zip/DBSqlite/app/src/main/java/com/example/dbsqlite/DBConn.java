package com.example.dbsqlite;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DBConn extends SQLiteOpenHelper {
    
    Context ct;
    public DBConn(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        ct = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table cust(id integer, name text, addr text, phno integer);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertData(int ID, String Name, String Addr, int phno) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("insert into cust(id,name,addr,phno) values(" + ID + ",'" + Name + "','" + Addr + "'," + phno + ");");
        Toast.makeText(ct, "Inserted", Toast.LENGTH_SHORT).show();
    }

    public String getData() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cr = db.rawQuery("select * from cust",null);
        StringBuilder sb = new StringBuilder();
        while(cr.moveToNext()){
            int id = cr.getInt(0);
            String name = cr.getString(1);
            String addr = cr.getString(2);
            int pno = cr.getInt(3);
            sb.append(id+"\t"+name+"\t"+addr+"\t"+pno+"\n");
        }
        return sb.toString();
    }


    public void deleteAllData() {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("delete from cust");
        }
    }

