package com.example.radio_checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    EditText e1,e2;
    RadioButton r1,r2,r3;
    CheckBox c1,c2,c3;
    Button b1,b2,b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.tv1);
        e1 = findViewById(R.id.et1);
        e2 = findViewById(R.id.et2);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);
        c1 = findViewById(R.id.c1);
        c2 = findViewById(R.id.c2);
        c3 = findViewById(R.id.c3);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.bt3);


        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(r1.isChecked()){
                    tv.setTextColor(Color.parseColor("RED"));
                }
            }
        });

        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(r2.isChecked()){
                    tv.setTextColor(Color.parseColor("GREEN"));
                }
            }
        });

        r3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(r3.isChecked()){
                    tv.setTextColor(Color.parseColor("BLUE"));
                }
            }
        });

        c1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(c1.isChecked()){
                    tv.setTypeface(Typeface.DEFAULT_BOLD);
                }
                else
                    tv.setTypeface(Typeface.DEFAULT);
            }
        });

        c2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(c2.isChecked()){
                    tv.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
                }
                else {
                    tv.setTypeface(Typeface.DEFAULT);
                }
            }
        });

        c3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(c3.isChecked()){
                    SpannableString str = new SpannableString(tv.getText().toString());
                    str.setSpan(new UnderlineSpan(),0,str.length(),0);
                    tv.setText(str);
                }
                else {
                    tv.setText(e1.getText()+" : "+e2.getText());
                }
            }
        });
    }

    public void closeApp(View view) {
        finish();
    }

    public void setTheText(View view) {
        tv.setText(e1.getText()+" : "+e2.getText());
    }

    public void resetEV(View view) {
        tv.setText("");
        e1.setText("");
        e2.setText("");
        r1.setChecked(false);
        r2.setChecked(false);
        r3.setChecked(false);
        c1.setChecked(false);
        c2.setChecked(false);
        c3.setChecked(false);
    }
}