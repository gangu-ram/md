package com.example.q_3_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText numInput;
    TextView resultLabel;
    Button checkButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numInput = findViewById(R.id.numInput);
        resultLabel = findViewById(R.id.resultLabel);
        checkButton = findViewById(R.id.checkButton);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num = Integer.parseInt(numInput.getText().toString());
                int numDigits = String.valueOf(num).length();
                int sum = 0;
                int tempNum = num;

                while (tempNum > 0) {
                    int digit = tempNum % 10;
                    sum += Math.pow(digit, numDigits);
                    tempNum /= 10;
                }

                if (sum == num) {
                    resultLabel.setText("The number is an Armstrong number.");
                } else {
                    resultLabel.setText("The number is not an Armstrong number.");
                }

            }
        });
    }
}