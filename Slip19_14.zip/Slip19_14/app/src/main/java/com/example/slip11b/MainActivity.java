package com.example.slip11b;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText e1;
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.editTextTextPersonName);
        t1 = findViewById(R.id.textView3);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int num = Integer.parseInt(e1.getText().toString());
        switch (item.getItemId()){
            case R.id.fact:
                int fact = 1;
                for (int i=1;i<=num;i++){
                    fact*=i;
                }
                t1.setText("Factorial \n"+fact);
                break;
            case R.id.sod:
                int sum = 0;
                while(num!=0){
                    sum = sum + num%10;
                    num = num/10;
                }
                t1.setText("Sum of digits \n"+sum);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}