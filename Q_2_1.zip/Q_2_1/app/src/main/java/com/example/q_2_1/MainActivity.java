package com.example.q_2_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editTextNumber;
    private Button buttonCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.editTextNumber);
        buttonCheck = findViewById(R.id.buttonCheck);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String numberString = editTextNumber.getText().toString();
                if (!numberString.isEmpty()) {
                    int number = Integer.parseInt(numberString);
                    if (isPerfectNumber(number)) {
                        Toast.makeText(MainActivity.this, number + " is a perfect number", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, number + " is not a perfect number", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a number", Toast.LENGTH_SHORT).show();
                }
            }

            private boolean isPerfectNumber(int number) {
                int sum = 1; // start from 1 as we know 1 is a divisor for every positive integer
                for (int i = 2; i <= number / 2; i++) {
                    if (number % i == 0) {
                        sum += i;
                    }
                }
                return sum == number;
            }
        });
    }
}