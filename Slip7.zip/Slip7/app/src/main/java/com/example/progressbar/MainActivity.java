package com.example.progressbar;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void OpenProgress(View view) {
        ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Download");
        pd.setMessage("Please Wait...");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setButton(ProgressDialog.BUTTON_NEGATIVE, "Cancel bolte", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        pd.show();
    }

    public void Exiteddd(View view) {
        AlertDialog.Builder alrt = new AlertDialog.Builder(this);
        alrt.setTitle("Alert Box");
        alrt.setMessage("Do you want to exit ?");
        alrt.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        alrt.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        alrt.setCancelable(true); //if click on outside of alrt box it will dismiss the alrt box
        alrt.show();
    }
}


/*
in xml add one TextView timepass ;
add 2 buttons and add onClick listener to appropriate methods
 */