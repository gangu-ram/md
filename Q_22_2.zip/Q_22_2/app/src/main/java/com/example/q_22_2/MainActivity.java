package com.example.q_22_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {
    Button bb1;
    RadioButton rr1,rr2,rr3;
    EditText ee1,ee2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rr1=findViewById(R.id.r1);
        rr2=findViewById(R.id.r2);
        ee1=findViewById(R.id.e1);
        rr3=findViewById(R.id.r3);
        ee2=findViewById(R.id.e2);
        bb1=findViewById(R.id.button);
    }

    public void operation(View view) {
        int num= Integer.parseInt(ee1.getText().toString());
        if(rr1.isChecked()) {
            if ((num % 2) == 0) {
                ee2.setText("EVEN");
            } else {
                ee2.setText("ODD");
            }
        }else if(rr2.isChecked()){
            if(num>=0){
                ee2.setText("POSITIVE NUMBER");
            }
            else{
                ee2.setText("NEGATIVE NUMBER");
            }
        }else if(rr3.isChecked()){
            int sq= num*num;
            ee2.setText(sq+"");
        }
    }
}