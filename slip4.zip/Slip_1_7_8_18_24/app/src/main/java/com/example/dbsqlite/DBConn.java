package com.example.dbsqlite;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DBConn extends SQLiteOpenHelper {
    
    Context ct;
    
    public DBConn(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        ct = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table cust(id integer primary key, name text);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertData(int parseInt, String toString) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("insert into cust(id,name) values("+ parseInt+",'"+toString+"');");
        Toast.makeText(ct, "Inserted", Toast.LENGTH_SHORT).show();
    }1

    public String getData() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cr = db.rawQuery("select * from cust",null);
        StringBuilder sb = new StringBuilder();
        while(cr.moveToNext()){
            int id = cr.getInt(0);
            String name = cr.getString(1);
            sb.append(id+"\t\t"+name+"\n");
        }
        return sb.toString();
    }
}
