package com.example.dbsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText eID,eNM;
    TextView res;
    Button b1,b2;

    DBConn mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eID = findViewById(R.id.editTextTextPersonName);
        eNM = findViewById(R.id.editTextTextPersonName2);
        res = findViewById(R.id.textView2);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);

        mydb = new DBConn(this,"cust",null,1);

    }

    public void saveData(View view) {
        mydb.insertData(Integer.parseInt(eID.getText().toString()),eNM.getText().toString());
    }

    public void loadData(View view) {
        String r = mydb.getData();
        res.setText(r);
    }
}