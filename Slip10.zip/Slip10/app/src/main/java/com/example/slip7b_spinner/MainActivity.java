package com.example.slip7b_spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button b1,b2;
    EditText e1;
    Spinner s;
    final List<String> list = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        e1 = findViewById(R.id.editTextTextPersonName);
        s = findViewById(R.id.spinner);

        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                e1.setText(parent.getItemAtPosition(position).toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                e1.setText("");
            }
        });
    }

    public void addItem(View view) {
        list.add(e1.getText().toString());

        ArrayAdapter<String> ad1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);
        ad1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        s.setAdapter(ad1);
    }

    public void removeItem(View view) {
        list.remove(e1.getText().toString());

        ArrayAdapter<String> ad1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);
        ad1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        s.setAdapter(ad1);
    }
}